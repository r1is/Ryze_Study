#pragma once



template<typename TYPE>
class CMyQueue
{
public:
    //���
    struct CMyNode {
        CMyNode() {
            m_pNext = nullptr;
            m_pPrev = nullptr;
        }
        CMyNode(const TYPE& Data,
            CMyNode* pPrev = nullptr,
            CMyNode* pNext = nullptr)
            :m_Data{ Data }, m_pNext{ pNext }, m_pPrev { pPrev }
        {

        }

        TYPE     m_Data;  //����
        CMyNode* m_pPrev; //���
        CMyNode* m_pNext; //���
    };
public:
    CMyQueue() {
        m_pHead = new CMyNode();
        m_pTail = new CMyNode();
        m_pHead->m_pNext = m_pTail;
        m_pTail->m_pPrev = m_pHead;
    }
    ~CMyQueue() {
        delete m_pHead;
        delete m_pTail;
    }

    void Enter(const TYPE& obj) {
        m_pTail->m_pPrev = m_pTail->m_pPrev->m_pNext = new CMyNode(obj, m_pTail->m_pPrev, m_pTail);
    }

    void Leave() {
        //  1 [2] 3
        CMyNode* pDelNode = m_pHead->m_pNext;
        m_pHead->m_pNext = pDelNode->m_pNext;
        pDelNode->m_pNext->m_pPrev = pDelNode->m_pPrev;
        delete pDelNode;
    }

    TYPE& Front() {
        return m_pHead->m_pNext->m_Data;
    }

    bool Empty() {
        return m_pHead->m_pNext == m_pTail;
    }
private:
    CMyNode* m_pHead;
    CMyNode* m_pTail;
};


