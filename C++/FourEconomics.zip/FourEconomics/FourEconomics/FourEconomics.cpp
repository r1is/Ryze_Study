﻿// FourEconomics.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "CMyQueue.h"
#include "CMyStack.h"

/*
* 思考题：
* a + (b - c) * d  +  e / f
* 1 + (2 - 3) * 4 + 6 / 5
* 从左往右遍历，优先级高的先算
* ####
* (    1
* +-   2
* /*   3
* )    4
* 数字  5

*/

/*
* 中缀转后缀流程
* 1 + 2*3  ===> 123*+
* 1.如果是数字显示（入栈）
* 2.如果是运算符
*	1） 栈是空，入栈
*	2） 栈不为空
*		 如果栈顶的运算符优先级大于等于当前运算符，计算，重复2
*		 当前运算符入栈、
*3.如果是括号
*	1） 左括号直接入栈
*	2） 右括号
*		1. 
* 4. 重复1
* 5. 如果栈不为空，出栈，重复4
*/



//获取优先级
/*
* (    1
* +-   2
* /*   3
* )    4
* 数字  5
*/
int GetPriority(char ch) {
	if (ch == '(') {
		return 1;
	}
	else if (ch == '+' ||ch == '-') {
		return 2;
	}
	else if (ch == '*' || ch == '/') {
		return 3;
	}
	else if (ch == ')') {
		return 4;
	}

	//操作数
	return 5;
}

//判断是否是数字
bool IsNumber(char ch) {
	return (ch >= '0' && ch <= '9');
}

//判断是否是运算符
bool  IsOperator(char ch) {
	return (ch == '(' || ch == ')'||ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

//两个操作数之间的计算函数
int Calc(int n1, int n2, char Oper) {
	switch (Oper)
	{
	case '+':
		return n1 + n2;
	case '-':
		return  n1 - n2;
	case '*':
		return  n1 * n2;
	case '/':
		return n1 / n2;
	}

	return 0;
}

//计算器
int Calculator(const char* pszExp, int nLen) {
	CMyStack<int>  s;
	for (int i = 0; i < nLen; i++) {
		//如果是数字就入栈
		if (IsNumber(pszExp[i])) {
			s.Push(pszExp[i] - '0');
		}
		//如果是运算符 就运算 
		else if(IsOperator(pszExp[i])){
			//获取操作数2
			int n2 = s.Top();
			s.Pop();

			//获取操作数1
			int n1 = s.Top();
			s.Pop();

			//结构入栈
			int ret = Calc(n1, n2, pszExp[i]);
			s.Push(ret);
		}
	}
	return s.Top();
}

//中序转后序
void ConverPostExp(const char* pszMidExp, char* pszPostExp, int nLen) {
	CMyStack<int> s;
	int nIndex = 0;

	for (int i = 0; i < nLen; i++) {
		//如果是数字  直接显示，此处是存放在pszPostExp中
		if (IsNumber(pszMidExp[i]) ){
			pszPostExp[nIndex] = pszMidExp[i];
				nIndex++;
		}
		//如果 是 运算符则运算，开始运算（此处是入栈）
		else if (IsOperator(pszMidExp[i])) {
			if (s.Empty()) {
				s.Push(pszMidExp[i]);
			}
			else {
				while (!s.Empty()) {
					if (GetPriority(s.Top()) >= GetPriority(pszMidExp[i])) {
						pszPostExp[nIndex] = s.Top();
						nIndex++;
						s.Pop();
					}
					else {
						break;
					}
				}
				s.Push(pszMidExp[i]);
			}
		}
		else if (pszMidExp[i] == '(') {
			s.Push(pszMidExp[i]);
		}
		else if (pszMidExp[i] == ')') {
			while (!s.Empty() && s.Top() != '(') {
				pszPostExp[nIndex++] = s.Top();
				s.Pop();
			}
			s.Pop();

		}

	}
	while (!s.Empty()) {
		pszPostExp[nIndex++] = s.Top();
		s.Pop();
	}

}

int main()
{
	char pszMidExp[100] = "1+(2-3)*(4+6/5)";
	char pszPostExp[14] = { 0 };
	scanf_s("%s",pszMidExp,sizeof(pszMidExp));
	printf("中缀表式:%s\r\n",pszMidExp);
	ConverPostExp(pszMidExp, pszPostExp, sizeof(pszMidExp) - 1);
	printf("后缀表式:%s\r\n", pszPostExp);
	printf("%s = %d \r\n", pszMidExp,Calculator(pszPostExp,sizeof(pszPostExp) - 1));

	return 0;
}

